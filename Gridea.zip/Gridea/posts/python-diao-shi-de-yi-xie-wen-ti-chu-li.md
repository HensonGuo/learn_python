---
title: 'python调试dll的一些问题处理总结'
date: 2022-08-22 16:03:19
tags: [python]
published: true
hideInList: false
feature: 
isTop: false
---
##### 1.调试一些dll文件时，需要将当前工作目录进行设置为dll文件所在目录
调用os.chdir(dir)进行设置
``` python
    def _openProcess(self):
        _isStartUpFromDebug = os.environ.get("_isStartUpFromDebug")
        if _isStartUpFromDebug:
            curDir = os.getcwd()
            os.chdir(misc.getCCPathForDebug())
        try:
            dll = ctypes.cdll.LoadLibrary(str(self._interfacePath))
            if _isStartUpFromDebug:
                os.chdir(curDir)
            return {"dll":dll}
        except Exception:
            return {}
```

##### 2.Python3向dll的接口传递字符串时，需要将字符串bytes处理
通过str.encode转为bytes
``` python
Wrapper.DLL.StartLive(self._liverInstance, str.encode(jsonParams))
```