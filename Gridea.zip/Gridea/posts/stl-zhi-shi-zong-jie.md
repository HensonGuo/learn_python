---
title: 'STL知识总结'
date: 2022-09-06 16:17:26
tags: [C++]
published: false
hideInList: false
feature: 
isTop: false
---
![](https://hensonguo.github.io/post-images/1662465422764.jpg)

### ArrayList
数组在内存中时连续存储的，所以其索引速度非常快，而且赋值和修改元素也比较简单。
修改元素比较麻烦，容易导致内存狼，容易导致数据溢出等等
ArrayList就完美克服了这些缺点。

优点：
其大小是按照其存储数据进行动态扩充和收缩的
不用考虑内存浪费和指定长度

缺点:
在ArrayList中可以同时插入不同类型的数据，比如string，char，int等等
因为ArrayList把这些数据当做object来处理的，所以这样是允许的
但是有一个问题，如果我们用ArrayList来处理问题的时候，很可能发生类型不匹配的错误
所以说ArrayList是不安全的
即使我们保证插入数据的时候很小心，但是在使用的时候，我们需要他们都转化成为原来类型来处理
这里就有了拆装箱的操作
可想而知，这样会有巨大的内存消耗


### list
正因为ArrayList不安全的原因，所以c#也出现了泛型的概念，List正是ArrayList的泛型类
``` c++
List<int> list = new List<int>();
//新增数据
 list.Add(123);
//修改数据 
list[0] = 345;
//移除数据
list.RemoveAt(0);
```
如果此时插入其他类型的数据，就会报错
这样避免了前面所说安全问题和拆装箱消耗内存的问题了

List容器底层是用双向循环链表实现的，相比双链表的结构的好处是构建List的容器的时候，
只需借助一个指针就可以轻松的表示List的首位元素

### hashmap
map的底层也是使用数组来实现，数组中每一项都是单向链表（链表和数组的结合体）
当链表长度大于一定的阈值，链表转换为红黑树，减少链表的查询时间
![](https://hensonguo.github.io/post-images/1662454854313.jpg)
在hashmap中使用数组加（链表或者红黑树）可以完美解决数组和链表的问题 使得查询 插入删除效率都比较高
对于同一个对象如果没有被修改，那么无论何时其哈希码都是相同的
对于两个对象 如果其内容不同 其哈希码也可能是相同的

当哈希表插入一个数据的时候
分为两种情况：
1.数组中索引处为空，这种情况直接将元素放入即可
2.数组中索引处不是空，那么我们判断该位置的元素和当前元素是否相等
如果相等我们直接覆盖，如果不相等 我们使用链表或者红黑树的形式存储该元素

### set
关于set的底层实现有两种说法，
第一种是c++的STL的set用的是红黑树
第二种是hash_set的hashtable
红黑树和哈希表最大的不同就是红黑树是有序结构，hashtable不是有序结构
如果只是判断set中的元素是否存在，hash显然更加适合，因为set的访问操作复杂度是log(N)，而使用hash底层实现hash_set近似O(1)

### map
map是key:value键值对的组合，map类型通常被称为关联数组(associative array)。与之相对，set就是关键字的简单组合。
``` c++
template <class Key,
    class Type,
    class Traits = less<Key>,
    class Allocator=allocator<pair <const Key, Type>>>
class map;
```
Key 要存储在映射中的键数据类型。
Type 要存储在映射中的元素数据类型。
Traits 一种提供函数对象的类型，该函数对象可将两个元素值作为排序键进行比较，以确定其在映射中的相对顺序。 此参数为可选自变量，默认值是二元谓词 less。在 C++ 14 中可以通过指定没有类型参数的 std:: less <> 谓词来启用异类查找。
Allocato 一种表示存储的分配器对象的类型，该分配器对象封装有关映射的内存分配和解除分配的详细信息。 此参数为可选参数，默认值为 allocator<pair<const Key, Type> >。


### vector
vector的底层实现很简单，就是一段连续的线性存储空间（可以理解为指针）
``` c++
//_Alloc 表示内存分配器，此参数几乎不需要我们关心
template <class _Ty, class _Alloc = allocator<_Ty>>
class vector{
    ...
protected:
    pointer _Myfirst;
    pointer _Mylast;
    pointer _Myend;
};
```
Myfirst指向的是vector容器对象的起始字节位置
MyLast指向的是最后一个元素的末尾字节
myend指向整个vector所占内存的末尾字节
![](https://hensonguo.github.io/post-images/1662465044223.jpg)

<font color=green>vector扩容</font>
1.完全弃用现在的内存空间，重新申请新的 内存空间
2.将旧的内存空间中的数据，按照原有顺序移动到新的内存空间中
3.最后将旧的内存空间释放
这也就是为什么vector扩容之后，与其相关的指针，引用，迭代器等都会失效的原因

由此可见vector的扩容是很好时的，为了降低再次分配内存的成本，每次扩容的时候，都会申请比用户需求更多的内存空间
这也就是vector容量的由来，以便之后使用


测试题：
符号匹配，判断是否合法：
``` c++
//判断括号是否合法--C++
#include <iostream>
#include <string>
#include <stack>
using namespace std;

int Match(char ch1,char ch2)
{// 匹配函数
    int t = 0;
    if(ch1 == '(' && ch2 == ')')    t = 1;
    if(ch1 == '[' && ch2 == ']')    t = 1;
    if(ch1 == '{' && ch2 == '}')    t = 1;
    return t;
}

bool chkLegal(string A) 
{// 检查函数
	if(A.size() == 0)   return false;
    stack<char> Stack;		// 定义一个栈容器
    for(int i=0;i<A.size();i++){
        if(A[i]=='['||A[i]=='('||A[i]=='{')
            Stack.push(A[i]);	// 左括号入栈
        if(A[i]==']'||A[i]==')'||A[i]=='}')
         {
            if(Stack.empty())   return false;               // 如果栈空还有右括号，不匹配
            if(!Match(Stack.top(), A[i]))  return  false;   // 如果没有对应匹配
            Stack.pop();
         }
    }
    if(Stack.empty())   return true;                        // 如果数量正确匹配
    else    return false;
}

int main(int argc, char *argv[])
{
    string A = "[a+b*(5-4)]";                   // 测试用例A，期望数出1
    string B = "[a+b*{5-4)]";                   // 测试用例B，期望数出0
    string C = "{[())]}";                       // 测试用例C，期望输出0
    string D = "{[a+b*(5-4)]";                  // 测试用例D，期望输出0
    string E = "";								// 测试用例D，期望输出0	
    cout << "String A is: " << chkLegal(A) << endl;
    cout << "String B is: " << chkLegal(B) << endl;
    cout << "String C is: " << chkLegal(C) << endl;
    cout << "String D is: " << chkLegal(D) << endl;
    cout << "String E is: " << chkLegal(E) << endl;
    return 0;
}
```