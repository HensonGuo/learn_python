---
title: '内存详解'
date: 2022-09-05 21:04:44
tags: [内存,C++]
published: true
hideInList: false
feature: 
isTop: false
---
### 1.什么是内存
**硬盘(ROM)** 可以存储的东西很多，但其传输数据的速度较慢。所以需要运行程序或打开数据时，这些数据必须从硬盘等存储器上先传到另一种容量小但速度快得多的存储器，之后才送入CPU进行执行处理。这中间的存储器就是 **内存(RAM)**。

### 2.什么是内存地址
+ 内存地址只是一个编号，代表一个内存空间；（ 内存地址是16进制保存的，一个内存（内存空间）是一个字节（8bit））
+ 内存地址所执行的内存单元大小就是1字节，跟内存地址位数无关（1字节=8bit）；

### 3.内存空间如何分配的
定义一个int类型的变量，找到一个空间伪4个字节的空间
![](https://hensonguo.github.io/post-images/1662383349486.jpg)
变量a占用4个字节的空间，但是内存地址是第一个字节的地址，也就是说上面的变量a的内存地址是238

### 4.内存地址的占用大小
+ 16位操作系统的内存地址占用大小是16位，即2字节
+ 32位操作系统的内存地址占用大小是32位，即4字节
+ 64位操作系统的内存地址占用大小是64位，即8字节
+ 128位操作系统的内存地址占用大小是128位，即16字节
  ![](https://hensonguo.github.io/post-images/1662430566465.jpg)
32位的CPU理论最多支持4GB的内存空间,CPU只能寻址2的32次方（4GB）
4位16进制表示的内存地址和用8位16进制表示的内存地址，其实都是代表一个8bit的存储空间而已：
![](https://hensonguo.github.io/post-images/1662430657816.jpg)

### 5.常用数据类型占用内存大小
<table class="reference">
<tbody><tr><th>类型</th><th>位</th><th>范围</th></tr>
<tr><td>char</td><td>1 个字节</td><td>-128 到 127 或者 0 到 255</td></tr>
<tr><td>unsigned char</td><td>1 个字节</td><td>0 到 255</td></tr>
<tr><td>signed char</td><td>1 个字节</td><td>-128 到 127</td></tr>
<tr><td>int</td><td>4 个字节</td><td>-2147483648 到 2147483647</td></tr>
<tr><td>unsigned int</td><td>4 个字节</td><td>0 到 4294967295</td></tr>
<tr><td>signed int</td><td>4 个字节</td><td>-2147483648 到 2147483647</td></tr>
<tr><td>short int</td><td>2 个字节</td><td>-32768 到 32767</td></tr>
<tr><td>unsigned short int</td><td>2 个字节</td><td>0 到 65,535</td></tr>
<tr><td>signed short int</td><td>2 个字节</td><td>-32768 到 32767</td></tr>
<tr><td>long int</td><td>8 个字节</td><td>-9,223,372,036,854,775,808 到 9,223,372,036,854,775,807</td></tr>
<tr><td>signed long int</td><td>8 个字节</td><td>-9,223,372,036,854,775,808 到 9,223,372,036,854,775,807</td></tr>
<tr><td>unsigned long int</td><td>8 个字节</td><td>0 到 18,446,744,073,709,551,615</td></tr>
<tr><td>float</td><td>4 个字节</td><td>精度型占4个字节（32位）内存空间，+/- 3.4e +/- 38 (~7 个数字)</td></tr>
<tr><td>double</td><td>8 个字节</td><td>双精度型占8 个字节（64位）内存空间，+/- 1.7e +/- 308 (~15 个数字)</td></tr>
<tr><td>long double</td><td>16 个字节</td><td>长双精度型 16 个字节（128位）内存空间，可提供18-19位有效数字。</td></tr>
<tr><td>wchar_t</td><td>2 或 4 个字节</td><td>1 个宽字符</td></tr>
</tbody></table>

![](https://hensonguo.github.io/post-images/1662431460894.jpg)

### 5.数组中内存地址
``` c++
int main(void)
{
	int a[5] = { 1,2,3,4,5 };
	int* ptr = (int*)(&a + 1);
	printf("%d,%d", *(a + 1), *(ptr-1));
	return 0;
}
```
假如数组a的地址是0x00{1,2,3,4,5}
那么数组中对应数据存储的地址分别是 0x00 0x04 0x08 0x0c 0x10，数组地址为数组中第一个数据的地址
&a+1表示数组地址整体位移1位，地址变为0x14{v1,v2,v3,v4,v5}，其中v为14后内存地址对应的值
a+1表示地址位置+1，为0x04，*(a+1) = 2
所以输出的值是2、5

char数组存储的都是对应的字符常量指针
![](https://hensonguo.github.io/post-images/1662446440941.jpg)
假如数组a的地址是0x00{addr1("1"), addr2("2"),...}
那么0x00 存储的是addr1，0x04存储的是addr2

``` c++
int main(void)
{
    const char* names[3] = { "sun","bin","sunbin" };
    cout << *names << endl; //数组的第一个item的值
	cout << names << endl;	//数组的地址，同是数组sum的地址，同是s的地址，存储地址即内存的起始位置
	cout << names[0] << endl; //item1的值，类似函数ptr->func()
	cout << names[1] << endl; //item2的值
	cout << *names[0] << endl; //相当于var = *names, var[0]
	cout << *names[1] << endl;
}
```
