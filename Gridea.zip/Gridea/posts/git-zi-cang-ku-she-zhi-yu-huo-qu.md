---
title: 'git子仓库设置与获取'
date: 2022-08-22 20:09:30
tags: [git]
published: true
hideInList: false
feature: 
isTop: false
---
1. 依赖仓库设置
   项目目录下创建.gitmodules文件，其文件格式为
   ```
   [submodule "apps"]
	    path = dirpath
	    url = ssh://git@xxxx.git
	    branch = branchname
	    ignore = all
    ```
    其中path为项目的子仓库存储目录
    url为对应的远程仓库地址

2. 子仓库获取
   git clone --recursive ssh://xxx.git