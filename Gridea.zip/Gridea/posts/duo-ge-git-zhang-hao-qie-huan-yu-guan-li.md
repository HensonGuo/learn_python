---
title: '多个git账号切换与管理'
date: 2022-08-22 16:42:51
tags: [git]
published: true
hideInList: false
feature: 
isTop: false
---
1. 创建两个或多个ssh账户
   ![](https://hensonguo.github.io/post-images/1661157988792.jpg)
2. 修改配置文件
   在.ssh目录下创建config文件并编辑
   ![](https://hensonguo.github.io/post-images/1661158154529.jpg)
3. 添加秘钥
   通过ssh-add添加id_rsa_work和id_rsa_person两个文件

4. 修改项目的git设置
   需要为不同的项目设置不同的git用户名和邮箱
   不设置的话则是用的git的默认设置（默认配置在{user}/.gitconfig配置下）
   找到项目目录下的.git文件夹，在该目录下找到config文件，设置好user
   [user]
	    name = xxxx
	    email = xxxxxx@qq.com