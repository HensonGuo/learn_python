---
title: '常用小工具汇总'
date: 2022-09-02 10:23:21
tags: [工具]
published: true
hideInList: false
feature: 
isTop: false
---
任务管理器：
[procexp](https://hensonguo.github.io/post-images/StudyPE%2B%20x64.zip)

磁盘文件分布情况查看器：
[spacesniffer](https://hensonguo.github.io/post-images/spacesniffer_1_3_0_2.zip)

PE文件分析器：
[StudyPE](https://hensonguo.github.io/post-images/StudyPE%2B%20x64.zip)

轻量级用户态及内核态调试工具
[Winddbg](https://docs.microsoft.com/zh-cn/windows-hardware/drivers/debugger/debugger-download-tools)

博客token:
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