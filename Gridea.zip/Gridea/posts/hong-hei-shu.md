---
title: '红黑树'
date: 2022-09-06 17:43:07
tags: []
published: true
hideInList: false
feature: 
isTop: false
---
又称为平衡二叉树，节点被标记为红色或者黑色，黑色是空节点，红色节点存储数据
1. 任意节点子树高度相差不大于1
2. 根节点是黑色的，叶节点也是不存储数据的，黑色的
3. 任何相邻两节点不能同时为红色
4. 任意节点到达其可达节点的叶节点间包含相同数量的黑色节点
   ![](https://hensonguo.github.io/post-images/1662458100324.jpg)

树的高度趋近于logn
因此在树上的任何操作（插入、删除、查找）的时间复杂度也是logn
![](https://hensonguo.github.io/post-images/1662458339689.jpg)

红黑树较AVL树的优点

AVL 树是高度平衡的，频繁的插入和删除，会引起频繁的rebalance，导致效率下降；
红黑树不是高度平衡的，算是一种折中，插入最多两次旋转，删除最多三次旋转。

所以红黑树在查找，插入删除的性能都是O(logn)，且性能稳定，所以STL里面很多结构包括map底层实现都是使用的红黑树。